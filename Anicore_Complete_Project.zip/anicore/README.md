# Anicore — Anime Catalogue & Streaming-Style Platform

A responsive black-and-red anime catalogue built with FastAPI, MongoDB, HTML, CSS and JavaScript. It includes user registration/login, search and genre filtering, anime/season/episode management, watchlists, watch progress, and an admin dashboard.

> This starter does not provide or scrape copyrighted anime streams. Add only video URLs and artwork that you own, are licensed to use, or are otherwise authorized to distribute. The video player accepts direct media URLs supported by the browser; it is not an HLS/DASH transcoding service.

## Features

- Responsive black/red interface and anime catalogue
- Search and genre filters
- Anime details, seasons and episodes
- User registration and login using signed JWT cookies
- Password hashing with Python's scrypt
- Watchlist and continue-watching progress
- Admin dashboard to add, edit and delete anime and episodes
- FastAPI JSON API and interactive API docs at `/docs`
- MongoDB persistence
- Environment-based configuration

## 1. Termux setup (Android)

Install Termux from the official F-Droid page: https://f-droid.org/packages/com.termux/

In Termux:

```bash
pkg update && pkg upgrade -y
pkg install python git nano -y
mkdir -p ~/projects
cd ~/projects
```

Download/unzip the project ZIP into `~/projects/anicore`, then:

```bash
cd ~/projects/anicore
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Fill in `MONGODB_URI`, `SECRET_KEY`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD`. Create a free MongoDB Atlas cluster and database user, allow your current IP in Network Access, and copy the Python driver connection string. Replace the username/password placeholders and URL-encode special characters in the password.

Generate a secret key:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Paste that value into `SECRET_KEY` in `.env`. Change the sample admin password to a strong unique password.

Start locally:

```bash
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Open `http://127.0.0.1:8000` in your Android browser. API docs: `http://127.0.0.1:8000/docs`.

Stop with `CTRL+C`. If you close and reopen Termux, run:

```bash
cd ~/projects/anicore
source .venv/bin/activate
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

## 2. MongoDB Atlas

1. Create an account at https://www.mongodb.com/atlas.
2. Create a free cluster.
3. Create a database user and password.
4. In Network Access, allow the IP address from which the app connects. For a hosted service, configure the host's outbound IP if fixed; otherwise follow the host's current MongoDB Atlas connectivity guidance. `0.0.0.0/0` allows connections from anywhere and is less restrictive; use it only if necessary and protect the database with a strong unique user password.
5. Select Connect → Drivers → Python and copy the URI into `MONGODB_URI`.
6. Set `DATABASE_NAME=anicore`.

The app creates collections and indexes automatically. On first startup, it creates an admin account if both `ADMIN_EMAIL` and `ADMIN_PASSWORD` are set and that email does not already exist.

## 3. Deploy online

You can deploy this same repository to a Python web host that supports FastAPI (for example Render or Railway) and use MongoDB Atlas as the database.

Set these environment variables in the host dashboard (do not upload `.env`):

- `MONGODB_URI`
- `DATABASE_NAME`
- `SECRET_KEY` (a new strong random value)
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `ENVIRONMENT=production`

The included `Procfile` and `Dockerfile` provide common start configurations. Configure the service to run:

```bash
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Enable HTTPS on the hosting provider. In production the app marks its auth cookie `Secure`, so login requires HTTPS. Do not use the development server with `--reload` in production.

## 4. Use the website

- Visit `/` for the catalogue.
- Register a normal account using the Register button.
- Sign in with the admin email/password configured before first startup.
- Visit `/admin` while signed in as admin.
- Add anime with a title, description, genres, year, poster URL and optional banner URL.
- Open an anime, add seasons/episodes, and provide an authorized direct video URL.
- Users can save anime to their watchlist and update watch progress.

## 5. API endpoints

- `GET /api/health`
- `GET /api/anime?search=...&genre=...`
- `GET /api/anime/{anime_id}`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/me/watchlist`
- `POST /api/me/watchlist/{anime_id}`
- `DELETE /api/me/watchlist/{anime_id}`
- `GET /api/me/progress`
- `POST /api/me/progress`
- `POST /api/admin/anime`
- `PUT /api/admin/anime/{anime_id}`
- `DELETE /api/admin/anime/{anime_id}`
- `POST /api/admin/anime/{anime_id}/episodes`
- `PUT /api/admin/episodes/{episode_id}`
- `DELETE /api/admin/episodes/{episode_id}`

Interactive API documentation is available at `/docs`.

## Security notes

- Never share your bot/site secrets or commit `.env`.
- Use HTTPS in production.
- Use a unique strong MongoDB database password and least-privilege database user.
- Configure MongoDB network access carefully.
- This starter uses cookie-based JWT authentication with `HttpOnly`, `SameSite=Lax`, and `Secure` in production. For a public production service, add CSRF protection, rate limiting, email verification, password reset, moderation, backups and monitoring before opening registration widely.
- Do not add third-party streams unless you have distribution rights.
