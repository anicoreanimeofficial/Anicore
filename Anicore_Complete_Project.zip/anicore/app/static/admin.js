const $ = id => document.getElementById(id);
let adminAnime = [];
function notify(msg) {
  const el = $("toast"); el.textContent = msg; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2500);
}
async function api(url, options={}) {
  const res = await fetch(url, {credentials:"same-origin", headers:{"Content-Type":"application/json", ...(options.headers||{})}, ...options});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}
function field(id) { return $(id).value.trim(); }
async function init() {
  try {
    const data = await api("/api/auth/me");
    if (!data.user || data.user.role !== "admin") {
      $("admin-gate").hidden = false; $("admin-workspace").hidden = true; return;
    }
    $("admin-gate").hidden = true; $("admin-workspace").hidden = false;
    await refreshAdmin();
  } catch(e) { $("admin-gate").hidden = false; }
}
async function refreshAdmin() {
  adminAnime = await api("/api/anime?limit=100");
  const select = $("e-anime");
  select.innerHTML = '<option value="">Choose anime</option>';
  adminAnime.forEach(a => { const o=document.createElement("option"); o.value=a.id; o.textContent=a.title; select.append(o); });
  renderAnime();
  await renderEpisodes();
}
function renderAnime() {
  const list = $("admin-anime-list"); list.replaceChildren();
  if (!adminAnime.length) { list.textContent = "No anime added yet."; return; }
  adminAnime.forEach(a => {
    const row = document.createElement("div"); row.className = "admin-row";
    const info = document.createElement("div"); const title=document.createElement("strong"); title.textContent=a.title;
    const small=document.createElement("small"); small.textContent=(a.genres||[]).join(", ");
    info.append(title,small);
    const actions=document.createElement("div"); actions.className="row-actions";
    const edit=document.createElement("button"); edit.className="btn btn-outline"; edit.textContent="Edit"; edit.onclick=()=>editAnime(a);
    const del=document.createElement("button"); del.className="btn btn-outline"; del.textContent="Delete"; del.onclick=()=>deleteAnime(a.id);
    actions.append(edit,del); row.append(info,actions); list.append(row);
  });
}
function editAnime(a) {
  $("anime-form-title").textContent="Edit anime";
  $("anime-id").value=a.id; $("a-title").value=a.title; $("a-description").value=a.description||"";
  $("a-genres").value=(a.genres||[]).join(", "); $("a-year").value=a.year||"";
  $("a-rating").value=a.rating||0; $("a-poster").value=a.poster_url||"";
  $("a-banner").value=a.banner_url||""; $("a-status").value=a.status||"Ongoing";
  window.scrollTo({top:0,behavior:"smooth"});
}
function resetAnime() { $("anime-form").reset(); $("anime-id").value=""; $("a-rating").value=0; $("a-status").value="Ongoing"; $("anime-form-title").textContent="Add anime"; }
async function deleteAnime(id) {
  if (!confirm("Delete this anime and its episodes?")) return;
  try { await api(`/api/admin/anime/${id}`,{method:"DELETE"}); notify("Anime deleted"); await refreshAdmin(); }
  catch(e) { notify(e.message); }
}
$("anime-form").addEventListener("submit",async e=>{
  e.preventDefault();
  const id=field("anime-id");
  const body={
    title:field("a-title"), description:field("a-description"),
    genres:field("a-genres").split(",").map(x=>x.trim()).filter(Boolean),
    year:field("a-year") ? Number(field("a-year")) : null,
    rating:Number(field("a-rating")||0), poster_url:field("a-poster"),
    banner_url:field("a-banner"), status:field("a-status")||"Ongoing"
  };
  try {
    await api(id?`/api/admin/anime/${id}`:"/api/admin/anime",{method:id?"PUT":"POST",body:JSON.stringify(body)});
    notify(id?"Anime updated":"Anime added"); resetAnime(); await refreshAdmin();
  } catch(e) { notify(e.message); }
});
$("anime-reset").addEventListener("click",resetAnime);
$("episode-form").addEventListener("submit",async e=>{
  e.preventDefault();
  const animeId=field("e-anime");
  if(!animeId) return notify("Choose an anime first");
  const body={
    anime_id:animeId, season:Number(field("e-season")||1), episode_number:Number(field("e-number")),
    title:field("e-title"), description:field("e-description"), video_url:field("e-video"),
    thumbnail_url:field("e-thumbnail"), duration:field("e-duration")
  };
  try {
    await api(`/api/admin/anime/${animeId}/episodes`,{method:"POST",body:JSON.stringify(body)});
    notify("Episode added"); $("episode-form").reset(); $("e-season").value=1; await renderEpisodes();
  } catch(e) { notify(e.message); }
});
async function renderEpisodes() {
  const list=$("admin-episode-list"); list.replaceChildren();
  for (const anime of adminAnime) {
    try {
      const detail=await api(`/api/anime/${anime.id}`);
      for (const ep of detail.episodes) {
        const row=document.createElement("div"); row.className="admin-row";
        const info=document.createElement("div"); const title=document.createElement("strong");
        title.textContent=`${anime.title} — S${ep.season} E${ep.episode_number}`;
        const small=document.createElement("small"); small.textContent=ep.title||"Episode";
        info.append(title,small);
        const del=document.createElement("button"); del.className="btn btn-outline"; del.textContent="Delete";
        del.onclick=async()=>{if(confirm("Delete this episode?")){try{await api(`/api/admin/episodes/${ep.id}`,{method:"DELETE"});notify("Episode deleted");await renderEpisodes();}catch(e){notify(e.message);}}};
        row.append(info,del); list.append(row);
      }
    } catch(e) { console.error(e); }
  }
  if(!list.children.length) list.textContent="No episodes added yet.";
}
$("admin-refresh").addEventListener("click",()=>refreshAdmin().catch(e=>notify(e.message)));
init();
