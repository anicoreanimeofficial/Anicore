const $ = (id) => document.getElementById(id);
let currentUser = null;
let authMode = "login";
let toastTimer;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: {"Content-Type": "application/json", ...(options.headers || {})},
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || "Request failed");
  return data;
}
function safeImage(url) {
  return url || "https://placehold.co/400x600/171519/ed2437?text=ANICORE";
}
function card(anime) {
  const el = document.createElement("article");
  el.className = "anime-card";
  const wrap = document.createElement("div");
  wrap.className = "poster-wrap";
  const img = document.createElement("img");
  img.src = safeImage(anime.poster_url);
  img.alt = anime.title;
  img.loading = "lazy";
  img.onerror = () => { img.src = "https://placehold.co/400x600/171519/ed2437?text=ANICORE"; };
  const rating = document.createElement("span");
  rating.className = "rating-pill";
  rating.textContent = `★ ${Number(anime.rating || 0).toFixed(1)}`;
  wrap.append(img, rating);
  const title = document.createElement("h3");
  title.className = "card-title";
  title.textContent = anime.title;
  const meta = document.createElement("p");
  meta.className = "card-meta";
  meta.textContent = `${anime.year || "—"} · ${(anime.genres || []).slice(0,2).join(", ")}`;
  el.append(wrap, title, meta);
  el.addEventListener("click", () => openAnime(anime.id));
  return el;
}
async function loadAnime() {
  const params = new URLSearchParams();
  if ($("search").value.trim()) params.set("search", $("search").value.trim());
  if ($("genre").value) params.set("genre", $("genre").value);
  const grid = $("anime-grid");
  grid.innerHTML = "";
  try {
    const items = await api(`/api/anime?${params}`);
    if (!items.length) {
      grid.innerHTML = '<div class="empty">No anime found. Admins can add titles from the admin studio.</div>';
      return;
    }
    items.forEach(item => grid.append(card(item)));
  } catch (error) {
    grid.innerHTML = `<div class="empty">${escapeText(error.message)}</div>`;
  }
}
function escapeText(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
async function openAnime(id) {
  try {
    const anime = await api(`/api/anime/${id}`);
    const box = $("anime-detail");
    box.replaceChildren();
    const banner = document.createElement("img");
    banner.className = "detail-hero";
    banner.src = safeImage(anime.banner_url || anime.poster_url);
    banner.alt = anime.title;
    const title = document.createElement("h2");
    title.textContent = anime.title;
    const meta = document.createElement("p");
    meta.textContent = `${anime.year || "Year unknown"} · ★ ${anime.rating}/10 · ${(anime.genres || []).join(", ")} · ${anime.status || ""}`;
    const desc = document.createElement("p");
    desc.textContent = anime.description || "No description available.";
    const actions = document.createElement("div");
    actions.className = "detail-actions";
    if (currentUser) {
      const save = document.createElement("button");
      save.className = "btn btn-red";
      save.textContent = "＋ Add to watchlist";
      save.onclick = async () => {
        try { await api(`/api/me/watchlist/${id}`, {method:"POST"}); toast("Added to your watchlist"); loadWatchlist(); }
        catch(e) { toast(e.message); }
      };
      actions.append(save);
    }
    const heading = document.createElement("h3");
    heading.textContent = "Episodes";
    const episodes = document.createElement("div");
    if (!anime.episodes.length) {
      episodes.innerHTML = '<p class="muted">Episodes have not been added yet.</p>';
    } else {
      anime.episodes.forEach(ep => {
        const row = document.createElement("div");
        row.className = "episode-row";
        const label = document.createElement("span");
        label.textContent = `S${ep.season} · E${ep.episode_number} — ${ep.title || "Episode"}`;
        const play = document.createElement("button");
        play.className = "btn btn-outline";
        play.textContent = "Play";
        play.disabled = !ep.video_url;
        play.onclick = () => playEpisode(ep, episodes);
        row.append(label, play);
        episodes.append(row);
      });
    }
    box.append(banner, title, meta, desc, actions, heading, episodes);
    $("anime-modal").classList.add("open");
  } catch(e) { toast(e.message); }
}
function playEpisode(ep, container) {
  if (!ep.video_url) return toast("No authorized video source added.");
  try {
    const url = new URL(ep.video_url);
    if (!["http:", "https:"].includes(url.protocol)) throw new Error();
  } catch { return toast("Invalid video URL."); }
  container.querySelector(".video-player")?.remove();
  const video = document.createElement("video");
  video.className = "video-player";
  video.controls = true;
  video.playsInline = true;
  video.src = ep.video_url;
  video.addEventListener("timeupdate", () => {
    if (currentUser && Math.floor(video.currentTime) % 15 === 0) {
      api("/api/me/progress", {method:"POST", body:JSON.stringify({
        episode_id:ep.id, position_seconds:Math.floor(video.currentTime),
        duration_seconds:Math.floor(video.duration || 0)
      })}).catch(()=>{});
    }
  });
  container.prepend(video);
  video.play().catch(()=>toast("Press play to start the video."));
}
async function refreshUser() {
  try {
    const data = await api("/api/auth/me");
    currentUser = data.user;
  } catch { currentUser = null; }
  const area = $("account-area");
  area.replaceChildren();
  if (currentUser) {
    const label = document.createElement("span");
    label.className = "muted";
    label.textContent = currentUser.email.split("@")[0];
    const out = document.createElement("button");
    out.className = "btn btn-outline";
    out.textContent = "Sign out";
    out.onclick = async () => {
      await api("/api/auth/logout", {method:"POST"});
      currentUser = null; await refreshUser(); loadWatchlist(); toast("Signed out");
    };
    area.append(label, out);
  } else {
    const btn = document.createElement("button");
    btn.className = "btn btn-outline";
    btn.textContent = "Sign in";
    btn.onclick = () => openAuth();
    area.append(btn);
  }
}
function openAuth() {
  authMode = "login";
  updateAuthMode();
  $("auth-message").textContent = "";
  $("auth-modal").classList.add("open");
}
function updateAuthMode() {
  const login = authMode === "login";
  $("auth-title").textContent = login ? "Sign in." : "Create account.";
  $("auth-submit").textContent = login ? "Sign in" : "Create account";
  $("auth-switch-text").textContent = login ? "New here?" : "Already a member?";
  $("auth-switch").textContent = login ? "Create account" : "Sign in";
  $("auth-password").autocomplete = login ? "current-password" : "new-password";
}
async function loadWatchlist() {
  const grid = $("watchlist-grid");
  grid.innerHTML = "";
  if (!currentUser) { grid.innerHTML = '<div class="empty">Sign in to save anime to your watchlist.</div>'; return; }
  try {
    const items = await api("/api/me/watchlist");
    if (!items.length) { grid.innerHTML = '<div class="empty">Your watchlist is empty. Explore the catalogue above.</div>'; return; }
    items.forEach(item => grid.append(card(item)));
  } catch(e) { grid.innerHTML = `<div class="empty">${escapeText(e.message)}</div>`; }
}
$("open-auth").addEventListener("click", openAuth);
$("auth-switch").addEventListener("click", () => { authMode = authMode === "login" ? "register" : "login"; updateAuthMode(); });
$("auth-form").addEventListener("submit", async event => {
  event.preventDefault();
  const message = $("auth-message");
  message.textContent = "Please wait...";
  try {
    await api(`/api/auth/${authMode}`, {method:"POST", body:JSON.stringify({
      email:$("auth-email").value, password:$("auth-password").value
    })});
    $("auth-modal").classList.remove("open");
    $("auth-form").reset();
    await refreshUser(); await loadWatchlist(); toast("Welcome to Anicore!");
  } catch(e) { message.textContent = e.message; }
});
document.querySelectorAll("[data-close]").forEach(btn => btn.addEventListener("click", () => $(btn.dataset.close).classList.remove("open")));
document.querySelectorAll(".modal").forEach(modal => modal.addEventListener("click", e => { if(e.target === modal) modal.classList.remove("open"); }));
let searchTimer;
$("search").addEventListener("input", () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadAnime, 250); });
$("genre").addEventListener("change", loadAnime);
(async () => { await refreshUser(); await loadAnime(); await loadWatchlist(); })();
